import { useState } from "react"

function Login(){

    let [msg,setMsg] = useState("Hello i am arpan")

    return(
        <>
        <h1>I am Login Page</h1>
        <h1>{msg}</h1>
        <button onClick={async () =>{
            let response = await fetch("http://localhost:4000/events/add_event")
            let response2 = await response.json()

            setMsg(response2.message)
        }
        }>
            click me
        </button>
        </>
    )
}

export default Login